
package com.example.weighwise;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Button manageAlertsButton = findViewById(R.id.manageAlertsButton);

        manageAlertsButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, KeepInTouchActivity.class);
            startActivity(intent);
        });

        databaseHelper = new DatabaseHelper(this);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (view, insets) -> {
                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());

                    view.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom);

                    return insets;
                });

        //create an account and save
        createAccountButton.setOnClickListener(view -> {
            String username = usernameEditText.getText()
                    .toString().trim();
            String password = passwordEditText.getText()
                    .toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Enter a username and password.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean created = databaseHelper.createUser(
                    username, password);

            if (created) {
                Toast.makeText(this,
                        "Account created! You can now log in.",
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this,
                        "Could not create account. Try another username.",
                        Toast.LENGTH_LONG).show();
            }
        });

        //check the saved user and pass
        loginButton.setOnClickListener(view -> {
            String username = usernameEditText.getText()
                    .toString().trim();
            String password = passwordEditText.getText()
                    .toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Enter your username and password.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean valid = databaseHelper.checkUser(
                    username, password);

            if (valid) {
                Toast.makeText(this,
                        "Login successful!",
                        Toast.LENGTH_SHORT).show();

                // open weight entry scrn after login
                Intent intent = new Intent(
                        MainActivity.this,
                        AddWeightActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);

            } else {
                Toast.makeText(this,
                        "Incorrect username or password.",
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}
