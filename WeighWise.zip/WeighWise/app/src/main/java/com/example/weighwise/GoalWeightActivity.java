
package com.example.weighwise;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class GoalWeightActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private EditText goalWeightEditText;
    private String username;

    private final int navy = Color.rgb(11, 31, 58);
    private final int blue = Color.rgb(23, 63, 107);
    private final int lightBlue = Color.rgb(217, 230, 245);
    private final int backgroundColor = Color.rgb(244, 247, 250);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        databaseHelper = new DatabaseHelper(this);
        username = getIntent().getStringExtra("username");

        // Main screen layout
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(28), dp(24), dp(24));
        layout.setBackgroundColor(backgroundColor);

        // Title
        TextView title = new TextView(this);
        title.setText("Set Goal Weight");
        title.setTextSize(28);
        title.setTextColor(navy);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout.LayoutParams titleParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
        titleParams.bottomMargin = dp(28);
        layout.addView(title, titleParams);

        // Weight input
        goalWeightEditText = new EditText(this);
        goalWeightEditText.setHint("Enter goal weight in lb");
        goalWeightEditText.setTextSize(18);
        goalWeightEditText.setTextColor(navy);
        goalWeightEditText.setHintTextColor(Color.GRAY);
        goalWeightEditText.setSingleLine(true);
        goalWeightEditText.setInputType(
                InputType.TYPE_CLASS_NUMBER
                        | InputType.TYPE_NUMBER_FLAG_DECIMAL
        );
        goalWeightEditText.setPadding(
                dp(12), dp(12), dp(12), dp(12)
        );
        goalWeightEditText.setBackground(createRoundedBackground(
                Color.WHITE, Color.rgb(210, 220, 230), dp(8)
        ));

        LinearLayout.LayoutParams inputParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(58)
                );
        inputParams.bottomMargin = dp(24);
        layout.addView(goalWeightEditText, inputParams);

        // Load saved goal
        if (username != null && !username.trim().isEmpty()) {
            double currentGoal =
                    databaseHelper.getGoalWeight(username);

            if (currentGoal > 0) {
                goalWeightEditText.setText(
                        String.valueOf(currentGoal)
                );
            }
        }

        // Save Goal button
        Button saveButton = new Button(this);
        saveButton.setText("SAVE GOAL");
        styleButton(saveButton, lightBlue);
        saveButton.setTextColor(navy);

        LinearLayout.LayoutParams buttonParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(54)
                );
        buttonParams.bottomMargin = dp(16);
        layout.addView(saveButton, buttonParams);

        // Back button
        Button backButton = new Button(this);
        backButton.setText("BACK");
        styleButton(backButton, blue);

        layout.addView(backButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(54)
        ));

        setContentView(layout);

        // Save goal
        saveButton.setOnClickListener(view -> {
            String text = goalWeightEditText.getText()
                    .toString().trim();

            if (text.isEmpty()) {
                Toast.makeText(this,
                        "Enter a goal weight",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (username == null || username.trim().isEmpty()) {
                Toast.makeText(this,
                        "Could not identify your account. Please log in again.",
                        Toast.LENGTH_LONG).show();
                return;
            }

            try {
                double goal = Double.parseDouble(text);

                if (!Double.isFinite(goal) || goal <= 0) {
                    Toast.makeText(this,
                            "Weight must be greater than zero",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean saved =
                        databaseHelper.saveGoalWeight(username, goal);

                Toast.makeText(this,
                        saved ? "Goal saved" : "Could not save goal",
                        Toast.LENGTH_SHORT).show();

                if (saved) {
                    finish();
                }

            } catch (NumberFormatException e) {
                Toast.makeText(this,
                        "Enter a valid weight",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Back to previous screen
        backButton.setOnClickListener(view -> finish());
    }

    private void styleButton(Button button, int color) {
        button.setTextColor(Color.WHITE);
        button.setTextSize(16);
        button.setTypeface(null, Typeface.BOLD);
        button.setAllCaps(true);
        button.setElevation(dp(3));
        button.setBackground(createRoundedBackground(
                color, color, dp(8)
        ));
    }

    private GradientDrawable createRoundedBackground(
            int fillColor, int strokeColor, int cornerRadius) {

        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(cornerRadius);
        drawable.setStroke(dp(1), strokeColor);

        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources()
                .getDisplayMetrics().density + 0.5f);
    }
}
