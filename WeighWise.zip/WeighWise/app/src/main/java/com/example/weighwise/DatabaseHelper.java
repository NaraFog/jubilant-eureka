
package com.example.weighwise;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeighWise.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Store user accounts
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password TEXT NOT NULL)");

        // Store daily weights
        db.execSQL("CREATE TABLE weights (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL, " +
                "weight REAL NOT NULL, " +
                "entry_date TEXT NOT NULL)");

        // Store goal weights
        db.execSQL("CREATE TABLE goals (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "goal_weight REAL NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        // Add database upgrades here
    }

    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert("users", null, values);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT id FROM users WHERE username=? AND password=?",
                new String[]{username, password});

        boolean valid = cursor.moveToFirst();
        cursor.close();

        return valid;
    }

    public boolean addWeight(String username, double weight,
                             String entryDate) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("weight", weight);
        values.put("entry_date", entryDate);

        long result = db.insert("weights", null, values);
        return result != -1;
    }

    public Cursor getWeights(String username) {
        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery(
                "SELECT id, weight, entry_date FROM weights " +
                        "WHERE username = ? ORDER BY entry_date DESC",
                new String[]{username});
    }

    public boolean saveGoalWeight(String username, double goalWeight) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("goal_weight", goalWeight);

        int updated = db.update(
                "goals", values, "username = ?",
                new String[]{username});

        if (updated > 0) {
            return true;
        }

        long result = db.insert("goals", null, values);
        return result != -1;
    }

    public double getGoalWeight(String username) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT goal_weight FROM goals WHERE username = ?",
                new String[]{username});

        double goalWeight = -1;

        if (cursor.moveToFirst()) {
            goalWeight = cursor.getDouble(0);
        }

        cursor.close();
        return goalWeight;
    }


    public boolean updateWeight(int id, String username, double weight, String entryDate) {
        android.content.ContentValues values = new android.content.ContentValues();
        values.put("weight", weight);
        values.put("entry_date", entryDate);

        android.database.sqlite.SQLiteDatabase db = getWritableDatabase();

        int rowsUpdated = db.update(
                "weights",
                values,
                "id = ? AND username = ?",
                new String[]{String.valueOf(id), username}
        );

        return rowsUpdated > 0;
    }

    public boolean deleteWeight(int id, String username) {
        android.database.sqlite.SQLiteDatabase db = getWritableDatabase();

        int rowsDeleted = db.delete(
                "weights",
                "id = ? AND username = ?",
                new String[]{String.valueOf(id), username}
        );

        return rowsDeleted > 0;
    }

}
