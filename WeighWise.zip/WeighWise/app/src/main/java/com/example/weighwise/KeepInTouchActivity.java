
package com.example.weighwise;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class KeepInTouchActivity extends AppCompatActivity {

    private TextView permissionStatus;
    private Button allowSmsButton;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {
                        if (granted) {
                            updatePermissionStatus(true);
                            Toast.makeText(
                                    this,
                                    "Text alert permission granted!",
                                    Toast.LENGTH_LONG
                            ).show();
                            openMainActivity();
                        } else {
                            updatePermissionStatus(false);
                            Toast.makeText(
                                    this,
                                    "Text alerts are off. You can still use WeighWise.",
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);
        Button backButton = findViewById(R.id.backButton);
        allowSmsButton = findViewById(R.id.allowSmsButton);
        Button denySmsButton = findViewById(R.id.denySmsButton);
        permissionStatus = findViewById(R.id.permissionStatus);

        backButton.setOnClickListener(view -> finish());

        allowSmsButton.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED) {
                updatePermissionStatus(true);
                openMainActivity();
            } else {
                smsPermissionLauncher.launch(
                        Manifest.permission.SEND_SMS
                );
            }
        });

        denySmsButton.setOnClickListener(view -> openMainActivity());

        updatePermissionStatus(
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED
        );
    }

    private void updatePermissionStatus(boolean enabled) {
        if (permissionStatus != null) {
            permissionStatus.setText(
                    enabled
                            ? "Text notification permission is granted"
                            : "Text notifications are currently off"
            );
        }

        if (allowSmsButton != null) {
            allowSmsButton.setText(
                    enabled
                            ? "CONTINUE"
                            : "TURN ON TEXT ALERTS"
            );
        }
    }

    private void openMainActivity() {
        Intent intent = new Intent(
                KeepInTouchActivity.this,
                MainActivity.class
        );
        startActivity(intent);
        finish();
    }
}
