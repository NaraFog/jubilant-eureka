
package com.example.weighwise;

import android.Manifest;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddWeightActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private EditText dateEditText;
    private EditText weightEditText;
    private String username;
    private double pendingWeight;
    private double pendingGoal;

    // Exact button color: #D9E7F5
    private static final int GOAL_BUTTON_COLOR =
            Color.rgb(217, 231, 245);

    private static final int NAVY_TEXT =
            Color.rgb(11, 31, 58);

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {
                        if (granted) {
                            sendGoalReachedSms(pendingWeight, pendingGoal);
                        } else {
                            Toast.makeText(
                                    this,
                                    "SMS permission denied. You can still use WeighWise.",
                                    Toast.LENGTH_LONG
                            ).show();
                            finish();
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        databaseHelper = new DatabaseHelper(this);

        dateEditText = findViewById(R.id.dateEditText);
        weightEditText = findViewById(R.id.weightEditText);

        Button backButton = findViewById(R.id.backButton);
        Button saveWeightButton = findViewById(R.id.saveWeightButton);
        Button historyButton = findViewById(R.id.historyButton);
        Button goalButton = findViewById(R.id.goalButton);

        username = getIntent().getStringExtra("username");

        if (username == null || username.trim().isEmpty()) {
            Toast.makeText(
                    this,
                    "Please log in first.",
                    Toast.LENGTH_LONG
            ).show();
            finish();
            return;
        }

        // Apply the exact #D9E7F5 color to SET GOAL WEIGHT.
        GradientDrawable goalBackground = createRoundedBackground(
                GOAL_BUTTON_COLOR,
                GOAL_BUTTON_COLOR,
                dp(30)
        );

        goalButton.setBackgroundTintList(null);
        goalButton.setBackground(goalBackground);
        goalButton.setBackgroundTintList(
                ColorStateList.valueOf(GOAL_BUTTON_COLOR)
        );
        goalButton.setTextColor(NAVY_TEXT);

        Calendar calendar = Calendar.getInstance();
        updateDate(calendar);

        dateEditText.setOnClickListener(view -> {
            DatePickerDialog datePicker = new DatePickerDialog(
                    this,
                    (picker, year, month, day) -> {
                        calendar.set(year, month, day);
                        updateDate(calendar);
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );

            datePicker.show();
        });

        saveWeightButton.setOnClickListener(view -> {
            String weightText =
                    weightEditText.getText().toString().trim();
            String date = dateEditText.getText().toString().trim();

            if (weightText.isEmpty() || date.isEmpty()) {
                Toast.makeText(
                        this,
                        "Enter a date and weight.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            try {
                double weight = Double.parseDouble(weightText);

                if (!Double.isFinite(weight) || weight <= 0) {
                    Toast.makeText(
                            this,
                            "Weight must be greater than zero.",
                            Toast.LENGTH_SHORT
                    ).show();
                    return;
                }

                boolean saved = databaseHelper.addWeight(
                        username,
                        weight,
                        date
                );

                if (saved) {
                    Toast.makeText(
                            this,
                            "Weight saved successfully!",
                            Toast.LENGTH_LONG
                    ).show();
                    checkGoal(weight);
                } else {
                    Toast.makeText(
                            this,
                            "Could not save weight. Please try again.",
                            Toast.LENGTH_LONG
                    ).show();
                }

            } catch (NumberFormatException e) {
                Toast.makeText(
                        this,
                        "Enter a valid weight.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        historyButton.setOnClickListener(view -> {
            Intent intent = new Intent(
                    AddWeightActivity.this,
                    WeightHistoryActivity.class
            );
            intent.putExtra("username", username);
            startActivity(intent);
        });

        goalButton.setOnClickListener(view -> {
            Intent intent = new Intent(
                    AddWeightActivity.this,
                    GoalWeightActivity.class
            );
            intent.putExtra("username", username);
            startActivity(intent);
        });

        backButton.setOnClickListener(view -> finish());
    }

    private void checkGoal(double savedWeight) {
        double goalWeight = databaseHelper.getGoalWeight(username);

        if (goalWeight <= 0) {
            finish();
            return;
        }

        if (savedWeight <= goalWeight) {
            pendingWeight = savedWeight;
            pendingGoal = goalWeight;

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED) {
                sendGoalReachedSms(savedWeight, goalWeight);
            } else {
                smsPermissionLauncher.launch(
                        Manifest.permission.SEND_SMS
                );
            }
        } else {
            finish();
        }
    }

    private void sendGoalReachedSms(double weight, double goal) {
        SharedPreferences preferences =
                getSharedPreferences("WeighWisePrefs", MODE_PRIVATE);

        String savedPhoneNumber =
                preferences.getString("phone_" + username, "");

        if (savedPhoneNumber == null ||
                savedPhoneNumber.trim().isEmpty()) {
            showPhoneNumberDialog(weight, goal);
        } else {
            sendSms(savedPhoneNumber, weight, goal);
        }
    }

    private void showPhoneNumberDialog(double weight, double goal) {
        EditText phoneInput = new EditText(this);
        phoneInput.setInputType(InputType.TYPE_CLASS_PHONE);
        phoneInput.setHint("Enter phone number");

        int padding = dp(20);
        phoneInput.setPadding(padding, padding, padding, padding);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Goal Reached!")
                .setMessage(
                        "Enter your phone number to receive a text message."
                )
                .setView(phoneInput)
                .setPositiveButton("Save & Send", null)
                .setNegativeButton(
                        "Cancel",
                        (dialogInterface, which) -> finish()
                )
                .create();

        dialog.setOnShowListener(dialogInterface ->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                        .setOnClickListener(view -> {
                            String phoneNumber = phoneInput.getText()
                                    .toString().trim();

                            String digits =
                                    phoneNumber.replaceAll("[^0-9]", "");

                            if (digits.length() < 7 ||
                                    digits.length() > 15) {
                                phoneInput.setError(
                                        "Enter a valid phone number."
                                );
                                return;
                            }

                            SharedPreferences preferences =
                                    getSharedPreferences(
                                            "WeighWisePrefs",
                                            MODE_PRIVATE
                                    );

                            preferences.edit()
                                    .putString(
                                            "phone_" + username,
                                            phoneNumber
                                    )
                                    .apply();

                            dialog.dismiss();
                            sendSms(phoneNumber, weight, goal);
                        })
        );

        dialog.show();
    }

    private void sendSms(
            String phoneNumber,
            double weight,
            double goal
    ) {
        String message =
                "Congratulations! You reached your WeighWise weight goal. "
                        + "Your saved weight is " + weight
                        + " lb and your goal is " + goal + " lb.";

        try {
            SmsManager smsManager = getSystemService(SmsManager.class);

            if (smsManager == null) {
                Toast.makeText(
                        this,
                        "SMS is not available on this device.",
                        Toast.LENGTH_LONG
                ).show();
                finish();
                return;
            }

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "Goal reached! SMS request submitted.",
                    Toast.LENGTH_LONG
            ).show();

        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Goal reached, but the SMS could not be sent.",
                    Toast.LENGTH_LONG
            ).show();
        }

        finish();
    }

    private void updateDate(Calendar calendar) {
        SimpleDateFormat dateFormat =
                new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        dateEditText.setText(dateFormat.format(calendar.getTime()));
    }

    private GradientDrawable createRoundedBackground(
            int fillColor,
            int strokeColor,
            int cornerRadius
    ) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(cornerRadius);
        drawable.setStroke(dp(1), strokeColor);

        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources()
                .getDisplayMetrics().density + 0.5f);
    }
}
