package com.example.weighwise;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class WeightHistoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private LinearLayout weightHistoryContainer;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_history);

        databaseHelper = new DatabaseHelper(this);

        username = getIntent().getStringExtra("username");

        weightHistoryContainer =
                findViewById(R.id.weightHistoryContainer);

        // Simple left arrow Back button
        TextView backHistoryButton =
                findViewById(R.id.backHistoryButton);

        backHistoryButton.setOnClickListener(view -> finish());

        // Add weight button
        FloatingActionButton addWeightButton =
                findViewById(R.id.addWeightButton);

        addWeightButton.setOnClickListener(view -> {
            Intent intent = new Intent(
                    WeightHistoryActivity.this,
                    AddWeightActivity.class
            );
            intent.putExtra("username", username);
            startActivity(intent);
        });

        loadWeightHistory();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (weightHistoryContainer != null && databaseHelper != null) {
            loadWeightHistory();
        }
    }

    private void loadWeightHistory() {
        weightHistoryContainer.removeAllViews();

        if (username == null || username.trim().isEmpty()) {
            Toast.makeText(
                    this,
                    "Could not identify the logged-in user.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        Cursor cursor = databaseHelper.getWeights(username);

        if (cursor == null) {
            Toast.makeText(
                    this,
                    "Unable to load weight history.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        try {
            if (cursor.getCount() == 0) {
                TextView emptyMessage = new TextView(this);
                emptyMessage.setText("No weight entries yet.");
                emptyMessage.setTextSize(16);
                emptyMessage.setPadding(16, 24, 16, 24);
                emptyMessage.setTextColor(
                        android.graphics.Color.rgb(11, 31, 58)
                );
                weightHistoryContainer.addView(emptyMessage);
                return;
            }

            while (cursor.moveToNext()) {
                int id = cursor.getInt(
                        cursor.getColumnIndexOrThrow("id")
                );

                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow("entry_date")
                );

                double weight = cursor.getDouble(
                        cursor.getColumnIndexOrThrow("weight")
                );

                addHistoryRow(id, date, weight);
            }
        } finally {
            cursor.close();
        }
    }

    private void addHistoryRow(int id, String date, double weight) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(12, 8, 8, 8);
        row.setMinimumHeight(60);

        row.setBackgroundColor(android.graphics.Color.WHITE);

        TextView dateText = new TextView(this);
        dateText.setLayoutParams(
                new LinearLayout.LayoutParams(0,
                        LinearLayout.LayoutParams.WRAP_CONTENT, 1)
        );
        dateText.setText(date);
        dateText.setTextSize(14);
        dateText.setTextColor(
                android.graphics.Color.rgb(11, 31, 58)
        );

        TextView weightText = new TextView(this);
        weightText.setLayoutParams(
                new LinearLayout.LayoutParams(0,
                        LinearLayout.LayoutParams.WRAP_CONTENT, 1)
        );
        weightText.setText(String.format(java.util.Locale.getDefault(),
                "%.2f lb", weight));
        weightText.setTextSize(14);
        weightText.setTextColor(
                android.graphics.Color.rgb(23, 63, 107)
        );

        Button editButton = new Button(this);
        editButton.setText("EDIT");
        editButton.setTextSize(10);
        editButton.setTextColor(android.graphics.Color.WHITE);
        editButton.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(
                        android.graphics.Color.rgb(23, 63, 107)
                )
        );

        Button deleteButton = new Button(this);
        deleteButton.setText("DELETE");
        deleteButton.setTextSize(10);
        deleteButton.setTextColor(android.graphics.Color.WHITE);
        deleteButton.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(
                        android.graphics.Color.rgb(23, 63, 107)
                )
        );

        row.addView(dateText);
        row.addView(weightText);
        row.addView(editButton);
        row.addView(deleteButton);

        editButton.setOnClickListener(view ->
                showEditDialog(id, date, weight)
        );

        deleteButton.setOnClickListener(view ->
                showDeleteDialog(id)
        );

        LinearLayout.LayoutParams rowParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        rowParams.bottomMargin = 2;
        weightHistoryContainer.addView(row, rowParams);
    }

    private void showEditDialog(int id, String currentDate,
                                double currentWeight) {

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(24, 8, 24, 8);

        EditText dateInput = new EditText(this);
        dateInput.setHint("Date");
        dateInput.setSingleLine(true);
        dateInput.setText(currentDate);

        EditText weightInput = new EditText(this);
        weightInput.setHint("Weight in pounds");
        weightInput.setInputType(
                android.text.InputType.TYPE_CLASS_NUMBER
                        | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        );
        weightInput.setText(String.valueOf(currentWeight));

        layout.addView(dateInput);
        layout.addView(weightInput);

        new AlertDialog.Builder(this)
                .setTitle("Edit Weight Entry")
                .setView(layout)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newDate = dateInput.getText()
                            .toString().trim();

                    String weightString = weightInput.getText()
                            .toString().trim();

                    if (newDate.isEmpty() || weightString.isEmpty()) {
                        Toast.makeText(this,
                                "Please enter both date and weight.",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        double newWeight =
                                Double.parseDouble(weightString);

                        if (newWeight <= 0) {
                            Toast.makeText(this,
                                    "Weight must be greater than zero.",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }

                        boolean updated = databaseHelper.updateWeight(
                                id, username, newWeight, newDate
                        );

                        if (updated) {
                            Toast.makeText(this,
                                    "Weight updated.",
                                    Toast.LENGTH_SHORT).show();
                            loadWeightHistory();
                        } else {
                            Toast.makeText(this,
                                    "Could not update weight.",
                                    Toast.LENGTH_SHORT).show();
                        }

                    } catch (NumberFormatException e) {
                        Toast.makeText(this,
                                "Enter a valid weight.",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void showDeleteDialog(int id) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Weight Entry")
                .setMessage("Are you sure you want to delete this entry?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> {
                    boolean deleted =
                            databaseHelper.deleteWeight(id, username);

                    if (deleted) {
                        Toast.makeText(this,
                                "Weight entry deleted.",
                                Toast.LENGTH_SHORT).show();
                        loadWeightHistory();
                    } else {
                        Toast.makeText(this,
                                "Could not delete weight entry.",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }
}